# Boykot Rehberi

GitHub Pages için hazır PWA proje dosyaları.

## Güncelleme
Yeni marka eklemek için sadece `data.json` dosyasını düzenleyin.

Alanlar:
- marka
- anaFirma
- durum
- kod
- kategori
- alternatif
- kaynak
- not
