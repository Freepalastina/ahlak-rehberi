let DATA = [];
let filter = "all";
let view = "search";
let deferredPrompt = null;

const labels = {
  boykot: "🔴 BOYKOT",
  dikkat: "🟠 DİKKAT",
  alternatif: "🟢 ALTERNATİF",
  inceleniyor: "⚪ İNCELENİYOR"
};

const search = document.getElementById("search");
const results = document.getElementById("results");
const stats = document.getElementById("stats");

function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function norm(value) {
  return String(value ?? "")
    .toLocaleLowerCase("tr-TR")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

function cleanStatus(value) {
  const s = norm(value || "inceleniyor");
  if (["boykot", "dikkat", "alternatif", "inceleniyor"].includes(s)) return s;
  return "inceleniyor";
}

function normalizeItem(item) {
  return {
    marka: String(item.marka ?? item.Marka ?? "İsimsiz Marka").trim(),
    anaFirma: String(item.anaFirma ?? item.anafirma ?? item["Ana Firma"] ?? "").trim(),
    durum: cleanStatus(item.durum ?? item.Durum),
    kod: String(item.kod ?? item.Kod ?? "").trim(),
    kategori: String(item.kategori ?? item.Kategori ?? "").trim(),
    alternatif: String(item.alternatif ?? item.Alternatif ?? "").trim(),
    kaynak: String(item.kaynak ?? item.Kaynak ?? item.kanyak ?? "").trim(),
    not: String(item.not ?? item.Not ?? "").trim()
  };
}

async function init() {
  try {
    const res = await fetch("data.json?v=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error("data.json bulunamadı");
    const json = await res.json();
    const list = Array.isArray(json) ? json : Array.isArray(json.data) ? json.data : [];
    DATA = list.map(normalizeItem).filter(x => x.marka);
    render();
  } catch (err) {
    stats.innerHTML = "";
    results.innerHTML = `<div class="empty"><b>Hata:</b> data.json yüklenemedi.<br>${esc(err.message)}<br><br>data.json, index.html ile aynı klasörde olmalı.</div>`;
  }
}

function currentList() {
  const q = norm(search.value);
  return DATA.filter(item => {
    const hay = norm([
      item.marka,
      item.anaFirma,
      item.durum,
      item.kod,
      item.kategori,
      item.alternatif,
      item.kaynak,
      item.not
    ].join(" "));
    const okQ = !q || hay.includes(q);
    const okF = filter === "all" || item.durum === filter;
    return okQ && okF;
  }).sort((a, b) => a.marka.localeCompare(b.marka, "tr"));
}

function renderStats() {
  const count = status => DATA.filter(x => x.durum === status).length;
  stats.innerHTML = `
    <div class="stat"><b>${count("boykot")}</b><small>Boykot</small></div>
    <div class="stat"><b>${count("dikkat")}</b><small>Dikkat</small></div>
    <div class="stat"><b>${count("alternatif")}</b><small>Alternatif</small></div>
    <div class="stat"><b>${count("inceleniyor")}</b><small>İnceleme</small></div>`;
}

function card(item) {
  return `<article class="card ${esc(item.durum)}" data-brand="${encodeURIComponent(item.marka)}">
    <div class="cardTop">
      <div>
        <div class="status">${labels[item.durum] || labels.inceleniyor}</div>
        <h2>${esc(item.marka)}</h2>
      </div>
      <div class="pill">${esc(item.kod || "-")}</div>
    </div>
    <div class="info">
      <span>Ana Firma</span><b>${esc(item.anaFirma || "-")}</b>
      <span>Kategori</span><b>${esc(item.kategori || "-")}</b>
      <span>Alternatif</span><b>${esc(item.alternatif || "-")}</b>
    </div>
  </article>`;
}

function renderSearch() {
  renderStats();
  const list = currentList();
  if (!list.length) {
    results.innerHTML = `<div class="empty">Sonuç bulunamadı.</div>`;
    return;
  }
  results.innerHTML = list.map(card).join("");
}

function groupBy(key) {
  const map = new Map();
  DATA.forEach(item => {
    const name = item[key] || "Belirtilmemiş";
    if (!map.has(name)) map.set(name, []);
    map.get(name).push(item);
  });
  return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0], "tr"));
}

function renderGroups(key, dataName) {
  renderStats();
  results.innerHTML = groupBy(key).map(([name, items]) => `
    <div class="groupItem" ${dataName}="${esc(name)}">
      <div><b>${esc(name)}</b><br><small>${items.length} marka</small></div>
      <span>›</span>
    </div>`).join("");
}

function renderAbout() {
  stats.innerHTML = "";
  results.innerHTML = `
    <div class="empty" style="text-align:left">
      <h2>ℹ️ Kullanım</h2>
      <p>Bu uygulama <b>data.json</b> dosyasını okur.</p>
      <p>Gerekli alanlar: <b>marka, anaFirma, durum, kod, kategori, alternatif, kaynak, not</b></p>
      <p>Durum değerleri: <b>boykot, dikkat, alternatif, inceleniyor</b></p>
      <p>Yeni marka eklemek için sadece <b>data.json</b> dosyasını güncelle.</p>
    </div>`;
}

function render() {
  if (view === "companies") return renderGroups("anaFirma", "data-company");
  if (view === "categories") return renderGroups("kategori", "data-category");
  if (view === "about") return renderAbout();
  renderSearch();
}

function setNav(name) {
  document.querySelectorAll(".bottomNav button").forEach(btn => {
    btn.classList.toggle("navActive", btn.dataset.view === name);
  });
}

search.addEventListener("input", () => {
  view = "search";
  setNav("search");
  render();
});

document.getElementById("clearBtn").addEventListener("click", () => {
  search.value = "";
  search.focus();
  view = "search";
  setNav("search");
  render();
});

document.querySelectorAll("[data-filter]").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("[data-filter]").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    filter = btn.dataset.filter || "all";
    view = "search";
    setNav("search");
    render();
  });
});

document.querySelectorAll(".bottomNav button").forEach(btn => {
  btn.addEventListener("click", () => {
    view = btn.dataset.view || "search";
    setNav(view);
    render();
  });
});

results.addEventListener("click", event => {
  const cardEl = event.target.closest("[data-brand]");
  if (cardEl) {
    const name = decodeURIComponent(cardEl.dataset.brand);
    const item = DATA.find(x => x.marka === name);
    showDetail(item);
    return;
  }

  const companyEl = event.target.closest("[data-company]");
  if (companyEl) {
    search.value = companyEl.dataset.company;
    view = "search";
    setNav("search");
    render();
    return;
  }

  const categoryEl = event.target.closest("[data-category]");
  if (categoryEl) {
    search.value = categoryEl.dataset.category;
    view = "search";
    setNav("search");
    render();
  }
});

function showDetail(item) {
  if (!item) return;
  const detailContent = document.getElementById("detailContent");
  const detailDialog = document.getElementById("detailDialog");
  detailContent.innerHTML = `
    <h2>${labels[item.durum] || labels.inceleniyor}<br>${esc(item.marka)}</h2>
    <p><b>Ana Firma:</b> ${esc(item.anaFirma || "-")}</p>
    <p><b>Kategori:</b> ${esc(item.kategori || "-")}</p>
    <p><b>Kod:</b> ${esc(item.kod || "-")}</p>
    <p><b>Alternatif:</b> ${esc(item.alternatif || "-")}</p>
    <p><b>Not:</b> ${esc(item.not || "-")}</p>
    ${item.kaynak ? `<p><a href="${esc(item.kaynak)}" target="_blank" rel="noopener">Kaynağı aç</a></p>` : ""}`;
  detailDialog.showModal();
}

document.getElementById("closeDialog").addEventListener("click", () => {
  document.getElementById("detailDialog").close();
});

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredPrompt = event;
  const installBtn = document.getElementById("installBtn");
  installBtn.hidden = false;
  installBtn.onclick = async () => {
    installBtn.hidden = true;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
  };
});

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}

init();
